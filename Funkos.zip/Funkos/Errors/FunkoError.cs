﻿namespace Funkos.Errors;

public static class FunkoError
{
    public static NotFoundError NotFound(long id) => NotFoundError.FromId(id, "Funko");
    public static NotFoundError NotFound() => NotFoundError.ListaVacia("Funkos");
    public static NotFoundError NotFound(string message) => NotFoundError.Messagee(message);

    public static ValidationError BadRequest(string message) => ValidationError.Create(message);
    public static ConflictError Duplicate(string nombre) => ConflictError.Duplicate("Funko", nombre);
    public static ConflictError Concurrency(string model, long id, string accion) => ConflictError.Concurrency(model, id.ToString(), accion);

}