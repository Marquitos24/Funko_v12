﻿using CSharpFunctionalExtensions;
using FluentValidation;
using Funkos.Dto;
using Funkos.Dto.Common;
using Funkos.Dto.Funko;
using Funkos.Errors;
using Funkos.Mappers;
using Funkos.Models;
using Funkos.Repositories;
using Funkos.Service.Storage;
using Funkos.Validations;
using Microsoft.EntityFrameworkCore;

namespace Funkos.Service;

public class FunkoService(IFunkoRepository repository, IValidator<FunkoCreateDto> _validatorCreateAsync, IValidator<FunkoUpdateDto> _validatorUpdateAsync, ILogger<FunkoService> logger, IStorageService storage ) : IFunkoService
{
    /*
     * public async Task<Result<List<FunkosConCategoriaDtoResponse>, DomainErrors>>  GetAllAsync(CancellationToken cancellationToken)
    {
        List<Funko> funkos = await repository.FindAllAsync(cancellationToken);
       // IEnumerable<FunkoQueryDto> funkosDto = service.GetAll();
        List<FunkosConCategoriaDtoResponse> funkoResponse = funkos.Select(f => FunkoMapper.ToListDtoResponse(f)).ToList();
        return Result.Success<List<FunkosConCategoriaDtoResponse>, DomainErrors>(funkoResponse);
    }
     */
    
    public async Task<Result<PagedResult<FunkosDtoResponse>, DomainErrors>> FindAllPagedAsync(FunkoFilterDto dto, CancellationToken cancellationToken)
    {
        logger.LogInformation("Obteniendo Funkos paginados - Página: {Page}, Tamaño: {Size}", dto.Page, dto.Size);

        // 1. Obtenemos la tupla del repo (FunkoFilterDto)
        var (funkos, totalCount) = await repository.FindAllPagedAsync(dto, cancellationToken);
        
        // 2. Mapeamos las entidades a tu FunkosDtoResponse real
        var dtos = funkos.ToDtoList();

        var pagedResult = new PagedResult<FunkosDtoResponse>
        {
            Items = dtos,
            TotalCount = totalCount,
            Page = dto.Page + 1,
            PageSize = dto.Size
        };

        return Result.Success<PagedResult<FunkosDtoResponse>, DomainErrors>(pagedResult);
    }
    
    public async Task<Result<FunkosDtoResponse, DomainErrors>> GetByIdAsync(long id, CancellationToken cancellationToken)
    {
        logger.LogInformation("Buscando Funko {Id}", id);
        if (id <= 0) return Result.Failure<FunkosDtoResponse, DomainErrors>(FunkoError.NotFound(id));
        Funko? funko = await repository.FindByIdAsync(id, cancellationToken); 
        logger.LogWarning("Funko {Id} NO encontrado ", id);
        if(funko == null) {logger.LogWarning("Funko {Id} NO encontrado ", id); return Result.Failure<FunkosDtoResponse, DomainErrors>(FunkoError.NotFound());} 
       
        FunkosDtoResponse funkoResponse =  FunkoMapper.ToDtoResponse(funko);
        return Result.Success<FunkosDtoResponse, DomainErrors>(funkoResponse);
    }
    
    public async Task<Result<FunkosDtoResponse, DomainErrors>> AddAsync(FunkoCreateDto newFunko, CancellationToken cancellationToken)
    {
        // Si la validación falla, ModelState.IsValid será false automáticamente
        var validationResult = await _validatorCreateAsync.ValidateAsync(newFunko);
        if (!validationResult.IsValid)
        {
            logger.LogInformation("Hay errores de validación");
            // Si falla, mapeamos los errores de FluentValidation a tu sistema de DomainErrors
            var errorsDescription = string.Join("; ", validationResult.Errors.Select(e => e.ErrorMessage));
            return Result.Failure<FunkosDtoResponse, DomainErrors>(FunkoError.BadRequest(errorsDescription));
        }
        
        var model = FunkoMapper.ToEntityCreate(newFunko);
        if (model == null) return Result.Failure<FunkosDtoResponse, DomainErrors>(FunkoError.NotFound()); logger.LogWarning("Funko NO creado ");
        
        //Comprobamos que el funko nuevo NO tiene un nombre igual a otro Funko
        bool yaExiste = await repository.ExistsByNameAsync(newFunko.Name, null, cancellationToken);
        if (yaExiste) return Result.Failure<FunkosDtoResponse, DomainErrors>(FunkoError.Duplicate(model.Name)); logger.LogWarning("Ya existe el funko");
        
        // --- GESTIÓN DE LA IMAGEN EN CREACIÓN ---
        if (newFunko.Image is not null && newFunko.Image.Length > 0)
        {
            // 1. Guardamos la imagen en la carpeta "funkos" usando el servicio
            var fileName = await storage.StoreAsync(newFunko.Image, "funkos", cancellationToken);
            // 2. Obtenemos su URL pública relativa y se la asignamos al modelo
            model.Imagen = storage.GetUrl(fileName, "funkos");
        }
        else
        {
            model.Imagen = "/uploads/funkos/default.png"; // Imagen por defecto si no se sube ninguna
        }
        
        Funko funko = await repository.CreateAsync(model, cancellationToken);
        FunkosDtoResponse funkoResponse = FunkoMapper.ToDtoResponse(funko);
        logger.LogInformation("Funko Creado correctamente");
        return Result.Success<FunkosDtoResponse, DomainErrors>(funkoResponse);
    }
    
    public async Task<Result<FunkosDtoResponse, DomainErrors>> UpdateAsync(long id, FunkoUpdateDto updatedFunko, CancellationToken cancellationToken)
    {
        // Si la validación falla, ModelState.IsValid será false automáticamente
        var context = new ValidationContext<FunkoUpdateDto>(updatedFunko);
        context.RootContextData["FunkoId"] = id;
        var validationResult = await _validatorUpdateAsync.ValidateAsync(context);
        if (!validationResult.IsValid)
        {
            logger.LogInformation("Hay errores de validación");
            // Si falla, mapeamos los errores de FluentValidation a tu sistema de DomainErrors
            var errorsDescription = string.Join("; ", validationResult.Errors.Select(e => e.ErrorMessage));
            return Result.Failure<FunkosDtoResponse, DomainErrors>(FunkoError.BadRequest(errorsDescription));
        }
        
        //Buscamos el funko por Id y comprobamos si existe, si no salta error
        var funkoId = await repository.FindByIdAsync(id, cancellationToken);
        if (id <= 0 || funkoId is null) { logger.LogWarning("No se encontro el Funko {id}", id); return Result.Failure<FunkosDtoResponse, DomainErrors>(FunkoError.NotFound(id));}
        
        //Convertimos el RequestDTO al Modelo y validamos, si es null salta error
        var funkoModel = FunkoMapper.ToEntityUpdate(updatedFunko);
        if (funkoModel is null) return Result.Failure<FunkosDtoResponse, DomainErrors>(FunkoError.NotFound()); logger.LogWarning("No guardo el Funko {id}", id);
        //Comprobamos que el Categoria actualizado NO tiene un nombre igual a otro Categoria
     
        // --- GESTIÓN DE LA IMAGEN EN ACTUALIZACIÓN ---
        if (updatedFunko.Image is not null && updatedFunko.Image.Length > 0)
        {
            // Guardamos la nueva imagen
            var fileName = await storage.StoreAsync(updatedFunko.Image, "funkos", cancellationToken);
            funkoModel.Imagen = storage.GetUrl(fileName, "funkos");

            // Borramos la imagen vieja del disco si no es la por defecto
            if (!string.IsNullOrEmpty(funkoId.Imagen) && !funkoId.Imagen.EndsWith("default.png"))
            {
                var oldFileName = Path.GetFileName(funkoId.Imagen);
                await storage.DeleteAsync(oldFileName, "funkos", cancellationToken);
            }
        }
        else
        {
            // Si no se adjunta nueva imagen en el Update, mantenemos la que ya tenía guardada
            funkoModel.Imagen = funkoId.Imagen;
        }
        
        //Comprobamos que el funko actualizado NO tiene un nombre igual a otro Funko
        //bool yaExiste = await repository.ExistsByNameAsync(funkoModel.Name, id, cancellationToken);
       // if (yaExiste) { logger.LogWarning("Funko {id} con nombre duplicado", id); return Result.Failure<FunkosDtoResponse, DomainErrors>(FunkoError.Duplicate(funkoModel.Name));} 

       try
       {
           //Actualizamos Funko y comprobamos que no sea null, si lo es salta error
           Funko? funko = await repository.UpdateAsync(id, funkoModel, cancellationToken);
           if (funko == null) return Result.Failure<FunkosDtoResponse, DomainErrors>(FunkoError.NotFound());

           //Transformamos a ResponseDTO
           FunkosDtoResponse funkoResponse = FunkoMapper.ToDtoResponse(funko);
           logger.LogInformation("Funko {id} actualizdo correctamente", id);
           //Devolvemos
           return Result.Success<FunkosDtoResponse, DomainErrors>(funkoResponse);
       }
       catch (DbUpdateConcurrencyException ex)
       {
           logger.LogWarning(ex, "Conflicto de concurrencia al actualizar el Funko {id}", id);
           var entry = ex.Entries.First();
           var databaseValues = await entry.GetDatabaseValuesAsync(cancellationToken);

           if (databaseValues is null)
           {
               return Result.Failure<FunkosDtoResponse, DomainErrors>(CategoriaError.NotFound(id));
           }
           
           return Result.Failure<FunkosDtoResponse, DomainErrors>(FunkoError.Concurrency("El Funko ",id, "modificado "));
       }
    }

    public async Task<Result<bool, DomainErrors>> DeleteAsync(long id, CancellationToken cancellationToken)
    {
        //Comprobamos que el Id existe, si no salta error
        var funkoId = await repository.FindByIdAsync(id, cancellationToken);
        if (id <= 0 || funkoId is null) return Result.Failure<bool, DomainErrors>(FunkoError.NotFound(id));
        
        try
        {
            var deleted = await repository.DeleteAsync(id, cancellationToken);
        
            if (!deleted) return Result.Failure<bool, DomainErrors>(FunkoError.NotFound(funkoId.Name));
            // Imagen: borramos archivo
            if (!string.IsNullOrEmpty(funkoId.Imagen) && !funkoId.Imagen.EndsWith("default.png"))
            {
                var fileName = Path.GetFileName(funkoId.Imagen);
                await storage.DeleteAsync(fileName, "funkos", cancellationToken);
            }
            
            logger.LogWarning("Funko {id} eliminado correctamente", id);
            return Result.Success<bool, DomainErrors>(true);
        }
        catch (DbUpdateConcurrencyException ex)
        {
            logger.LogWarning(ex, "Conflicto de concurrencia al actualizar el Funko {id}", id);
            var entry = ex.Entries.First();
            var databaseValues = await entry.GetDatabaseValuesAsync(cancellationToken);

            if (databaseValues is null)
            {
                return Result.Failure<bool, DomainErrors>(CategoriaError.NotFound(id));
            }
           
            return Result.Failure<bool, DomainErrors>(FunkoError.Concurrency("El Funko ",id, "eliminado "));
        }
    }
    
}